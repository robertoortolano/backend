package com.example.model;

import jakarta.persistence.*;
import java.util.*;

public enum RoleName {
    ADMIN,
    USER
}
