package com.example.model;

import jakarta.persistence.*;
import java.util.*;

@Entity
public class Project {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @ManyToOne
    private Tenant tenant;

    @ManyToOne
    private ItemTypeSet itemTypeSet;
}