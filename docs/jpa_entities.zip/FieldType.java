package com.example.model;

import jakarta.persistence.*;
import java.util.*;

public enum FieldType {
    Checkbox,
    RadioButton,
    Date,
    DateTime,
    Number,
    RTF,
    SingleList,
    MultiList,
    CascadingList,
    Text,
    Link,
    SingleUser,
    MultiUser,
    SingleGroup,
    MultiGroup
}
